#!/usr/bin/python
#config file containing credentials for rds mysql instance
db_username = "admin"
db_password = "zuqryt-bisVug-2hohzo"
db_name = "gooddriver"
db_endpoint = "cpsc4910-t8.cobd8enwsupz.us-east-1.rds.amazonaws.com"
